﻿
//  prev.Add|data|next.Add == prev.Add|data|next.Add


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoublyLinkList
{
    class Node
    {
        public int data;
        public Node nextAddr, prevAddr;
    }
    class Double
    {
        public Node head;
        public int count;

        public Double()
        {
            head = null;
            count = 0;
        }

        public Node CreateNode(int ele)
        {
            Node temp = new Node();
            temp.data = ele;
            temp.nextAddr = null;
            temp.prevAddr = null;
            count++;
            return temp;
        }

        public void insertBegin(int ele)
        {
            Node newnode = CreateNode(ele);
            if (head == null)
                head = newnode;
            else
            {
                newnode.nextAddr = head;
                head = newnode;
                head.prevAddr = newnode;
            }
            
        }

        public void insertEnd(int ele)
        {
            Node newnode = CreateNode(ele);
            if (head == null)
                head = newnode;
            else
            {
                Node temp = head;
                while (temp.nextAddr != null)
                    temp = temp.nextAddr;

                temp.nextAddr = newnode;
                newnode.prevAddr = temp;
            }
        }

        public void insertPos(int ele,int pos)
        {
            if (pos == 1)
                insertBegin(ele);
            else if (pos == count + 1)
                insertEnd(ele);
            else
            {
                Node newnode = CreateNode(ele);
                Node pn, cn;
                pn = cn = head;
                for(int i = 1; i < pos; i++)
                {
                    pn = cn;         // pn = cn.prevAddr
                    cn = cn.nextAddr;   
                    cn.prevAddr = pn;
                }
                pn.nextAddr = newnode;
                newnode.prevAddr = pn;
                newnode.nextAddr = cn;
                cn.prevAddr = newnode;
            }
        }

        public void deleteBegin()
        {
            if(head==null)
                Console.WriteLine("No elements in List");
            else
            {
                Node temp = head;
                head = head.nextAddr;
                Console.WriteLine("Deleted: "+temp.data);
                //head.prevAddr = null;
                temp = null;
            }
        }

        public void deleteEnd()
        {
            if(head==null)
                Console.WriteLine("No elements in List");
            else
            {
                Node pn, cn;
                pn = cn = head;
                while (cn.nextAddr != null)
                {
                    pn = cn;
                    cn = cn.nextAddr;
                    cn.prevAddr = pn;
                }
                if (pn == cn)
                    head = null;
                pn.nextAddr = null;
                Console.WriteLine("Deleted: "+cn.data);
                cn = null;
                count--;
            }
        }

        public void deletePos(int pos)
        {
            if (pos == 1)
                deleteBegin();
            else if (pos == count)
                deleteEnd();
            else
            {
                Node pn, cn;
                pn = cn = head;
                for(int i = 1; i < pos; i++)
                {
                    pn = cn;         
                    cn = cn.nextAddr;
                    cn.prevAddr = pn;
                }
                pn.nextAddr = cn.nextAddr;
                cn.prevAddr = pn;
                Console.WriteLine("Deleted: "+cn.data);
                cn = null;
                count--;
            }
                
        }
        
        public void Find(int key)
        {
            Node temp = head;
            int flag,loc=1, c=0;
            if(temp==null)
                Console.WriteLine("Key not found");
            else
            {
                while (temp != null)
                {
                    if (temp.data == key)
                    {
                        c++;
                        Console.WriteLine("Key found at " + loc);
                        flag = 0;
                    }
                    else
                        flag = 1;
                    temp = temp.nextAddr;
                    loc++;
                }
            }
            
        }

        public void findOccurance(int key, int occ = 0)
        {
            Node temp = head;
            int flag=0, loc = 1, c = 0;
            if (temp == null)
                Console.WriteLine("Key not found");
            else
            {
                while (temp != null)
                {
                    if (temp.data == key)
                    {
                        c++;
                        Console.WriteLine("Key found at " + loc);
                        flag = 1;
                        if(c==occ)
                            Console.WriteLine("Found at: "+c);
                    }
                    temp = temp.nextAddr;
                    loc++;
                    if(flag==0)
                        Console.WriteLine("Not found");
                }
                
                
            }
        }

        public void Display()
        {
            if(head==null)
                Console.WriteLine("No elements are here");
            else
            {
                Console.WriteLine("==========================");
                Console.WriteLine("\nElements list is here");
                Node temp=head;
                
                while (temp != null)
                {
                    Console.Write(temp.data+" ");
                    temp = temp.nextAddr;
                }
                Console.WriteLine("\n==========================");
            }
        }

    }
}
