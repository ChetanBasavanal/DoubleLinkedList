﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoublyLinkList
{
    class Program
    {
        static void Main(string[] args)
        {
            Double ob = new Double();
            int ch, pos, ele,key,occ;
            do
            {
                Console.WriteLine("=======================");
                Console.WriteLine("1. Insert at Begining");
                Console.WriteLine("2. Insert at end");
                Console.WriteLine("3. Insert at Position");
                Console.WriteLine("4. Delete at Begining");
                Console.WriteLine("5. Delete at End");
                Console.WriteLine("6. Delete at Position");
                Console.WriteLine("7. Display");
                Console.WriteLine("8. Find a value");
                Console.WriteLine("9. Find Occurances");
                Console.WriteLine("0. Exit");
                Console.WriteLine("\nPlease enter your choice");
                ch = int.Parse(Console.ReadLine());

                switch (ch)
                {
                    case 1: Console.WriteLine("Enter the Element");
                        ele = int.Parse(Console.ReadLine());
                        ob.insertBegin(ele);
                         break;

                    case 2:
                        Console.WriteLine("Enter the element");
                        ele = int.Parse(Console.ReadLine());
                        ob.insertEnd(ele);
                        break;

                    case 3:
                        Console.WriteLine("Enter the Element");
                        ele = int.Parse(Console.ReadLine());
                        do
                        {
                            Console.WriteLine("Enter Postition");
                            pos = int.Parse(Console.ReadLine());
                        } while (pos < 1 || pos > ob.count + 1);
                        ob.insertPos(ele, pos);
                        break;

                    case 4: ob.deleteBegin();
                        break;

                    case 5: ob.deleteEnd();
                        break;

                    case 6:
                        do
                        {
                            Console.WriteLine("Enter Position");
                            pos = int.Parse(Console.ReadLine());
                        } while (pos < 1 || pos > ob.count);
                        ob.deletePos(pos);
                        break;

                    case 8:
                        do
                        {
                            Console.WriteLine("Enter the key");
                            key = int.Parse(Console.ReadLine());
                        } while (key < 1);

                        ob.Find(key);
                        break;

                    case 9:
                        do
                        {
                            Console.WriteLine("Enter key");
                            key = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Occurance");
                            occ = int.Parse(Console.ReadLine());
                        } while (key < 1);
                        ob.findOccurance(11, 3);
                        break;

                    case 7:
                        ob.Display();
                        break;
                    case 0: break;
                }
            } while (ch != 0);
        }
    }
}
